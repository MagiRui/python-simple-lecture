# -*- coding: utf-8 -*-
"""
Created on Mon Nov 26 13:57:58 2019

@author: Yuhong
"""

def return_mul_val(): 
    my_str = "Hello Python"
    num    = 20
    return my_str, num

  
str_, x = return_mul_val() 

print(str_, x) 


