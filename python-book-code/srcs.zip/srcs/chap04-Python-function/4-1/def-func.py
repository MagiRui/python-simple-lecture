# -*- coding: utf-8 -*-
"""
Created on Fri Nov 23 18:09:50 2018

@author: Yuhong
"""

# 计算面积函数
def area(width, height):
    return width * height
  
w = 4
h = 5
print("width =", w, " height =", h, " area =", area(w, h))
