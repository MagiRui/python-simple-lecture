#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct  1 16:20:28 2019

@author: yhilly
"""

def foo(s):
    n = int(s)
    print('n = {}'.format(n))
    return 10 / n

foo('0')