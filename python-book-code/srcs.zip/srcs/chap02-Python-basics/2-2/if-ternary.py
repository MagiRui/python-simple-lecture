# -*- coding: utf-8 -*-
"""
Created on Fri Nov 23 14:58:18 2018

@author: Yuhong
"""

x = 10
y = 20

#if x < y :
#    small = x
#else:
#    small = y

small = x if x < y else y

print (small)

