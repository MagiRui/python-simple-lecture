# -*- coding: utf-8 -*-
"""
Created on Wed Sep  4 08:39:33 2019

@author: Yuhong
"""

#import inspect
#vars = {}

num1 = 2
num2 = 4
result = num1 + num2

print("result = ", result)

#vars = inspect.currentframe().f_locals