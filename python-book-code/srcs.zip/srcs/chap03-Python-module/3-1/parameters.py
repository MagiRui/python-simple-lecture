# -*- coding: utf-8 -*-
"""
Created on Wed Nov 28 07:07:45 2018

@author: Yuhong
"""
# 我所在的文件是parameters.py
PI = 3.1415926

def paraTest():         #定义测试函数
    print ("PI = ", PI)

if __name__ == '__main__':
    paraTest()              #调用测试函数