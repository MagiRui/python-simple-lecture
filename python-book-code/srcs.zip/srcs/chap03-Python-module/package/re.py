def test():
    print ("I am re")
